package com.example.lessonmovie;


import java.util.List;

public class MovieList {
    public List<MovieModel> results;
}
