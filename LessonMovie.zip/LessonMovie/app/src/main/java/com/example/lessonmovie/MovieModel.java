package com.example.lessonmovie;

public class MovieModel {
    private final String imageUrl;
    private final String name;
    private final String date;
    private final String description;

    public MovieModel(String imageUrl, String name, String date, String description) {
        this.imageUrl = imageUrl;
        this.name = name;
        this.date = date;
        this.description = description;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public String getName() {
        return name;
    }

    public String getDate() {
        return date;
    }

    public String getDescription() {
        return description;
    }
}
