package com.example.lessonmovie;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.widget.Toast;

import com.example.lessonmovie.databinding.ActivityMainBinding;
import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.IOException;
import java.util.List;

import okhttp3.Cache;
import okhttp3.HttpUrl;
import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {
    private ActivityMainBinding binding;
    private MoveListAdapter adapter = new MoveListAdapter();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.recycler.setAdapter(adapter);
        getDataFromNetwork();

    }

    private void getDataFromNetwork() {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://api.themoviedb.org/3/")
                .addConverterFactory(GsonConverterFactory.create(getGson()))
                .client(getClient())
                .build();
        MovieApi api = retrofit.create(MovieApi.class);
        api.getPopularMovie(1).enqueue(new Callback<List<MovieModel>>() {
            @Override
            public void onResponse(@NonNull Call<List<MovieModel>> call, @NonNull Response<List<MovieModel>> response) {
                if (response.code() == 200) addToRecycler(response.body());
                else
                    showError(response.code());
            }

            @Override
            public void onFailure(@NonNull Call<List<MovieModel>> call, @NonNull Throwable t) {
                Toast.makeText(MainActivity.this, "Invalid response. Error: " + t.getMessage(),
                        Toast.LENGTH_LONG).show();
            }
        });
    }

    private void showError(int code) {
        Toast.makeText(MainActivity.this, "Invalid response. Code: " + code,
                Toast.LENGTH_LONG).show();
    }

    private Gson getGson() {
        return new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.IDENTITY).create();
    }

    private void addToRecycler(List<MovieModel> items) {
        adapter.setItems(items);
    }

    private OkHttpClient getClient() {
        OkHttpClient.Builder client = new OkHttpClient.Builder();
        client.cache(new Cache(getApplicationContext().getCacheDir(), 10L * 1024 * 1024));
        Interceptor interceptor = chain -> {
            Request request = chain.request();
            HttpUrl newUrl = request
                    .url()
                    .newBuilder()
                    .addQueryParameter("api_key", "2e774b038b2dc15a1db7397f1b6b63a7")
                    .build();
            return chain.proceed(request.newBuilder().url(newUrl).build());
        };
        return client.addInterceptor(interceptor).build();

    }

}
